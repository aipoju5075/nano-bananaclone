﻿# Build Artifact (Next.js)

This zip contains the production build output (`.next/`) plus `public/` and config.

Run (on the target machine):
- `pnpm install --prod --frozen-lockfile`
- `pnpm start`

Notes:
- `.env.local` is intentionally NOT included. Provide environment variables on the server.
- If you deploy to serverless/edge, you may need a different packaging strategy.
