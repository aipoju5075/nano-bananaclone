var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/node_modules__pnpm_79987fe7._.js")
R.c("server/chunks/[root-of-the-server]__ebfb06fd._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_5bfe9259.js")
R.m("[project]/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/generate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/.pnpm/next@16.0.10_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/generate/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
