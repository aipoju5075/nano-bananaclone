module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/api/generate/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$openai$40$6$2e$16$2e$0_zod$40$3$2e$25$2e$76$2f$node_modules$2f$openai$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/openai@6.16.0_zod@3.25.76/node_modules/openai/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$openai$40$6$2e$16$2e$0_zod$40$3$2e$25$2e$76$2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/openai@6.16.0_zod@3.25.76/node_modules/openai/client.mjs [app-route] (ecmascript) <export OpenAI as default>");
;
const runtime = "nodejs";
function getImageUrls(body) {
    const urls = (body.images || []).filter((img)=>typeof img === "string").filter((url)=>url.startsWith("data:image/") || url.startsWith("http"));
    return urls.slice(0, 9);
}
async function POST(req) {
    const apiKey = process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
        return Response.json({
            error: "Missing OPENROUTER_API_KEY."
        }, {
            status: 500
        });
    }
    let body;
    try {
        body = await req.json();
    } catch  {
        return Response.json({
            error: "Invalid JSON body."
        }, {
            status: 400
        });
    }
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (!prompt) return Response.json({
        error: "Prompt is required."
    }, {
        status: 400
    });
    const inputImages = body.mode === "image-to-image" ? getImageUrls(body) : [];
    if (body.mode === "image-to-image" && inputImages.length === 0) {
        return Response.json({
            error: "At least one image is required for image-to-image."
        }, {
            status: 400
        });
    }
    const siteUrl = process.env.OPENROUTER_SITE_URL || "http://localhost:3000";
    const appName = process.env.OPENROUTER_APP_NAME || "image-editor-clone";
    const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$openai$40$6$2e$16$2e$0_zod$40$3$2e$25$2e$76$2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__["default"]({
        baseURL: "https://openrouter.ai/api/v1",
        apiKey,
        defaultHeaders: {
            "HTTP-Referer": siteUrl,
            "X-Title": appName
        }
    });
    const content = [
        {
            type: "text",
            text: prompt
        }
    ];
    if (body.mode === "image-to-image") {
        for (const url of inputImages){
            content.push({
                type: "image_url",
                image_url: {
                    url
                }
            });
        }
    }
    // OpenRouter supports image generation via `modalities: ["image","text"]` for this model.
    // The upstream OpenAI SDK types don't currently include "image" in `modalities`.
    const selectedModel = body.model === "google/gemini-2.5-flash-image" ? body.model : "google/gemini-2.5-flash-image";
    const completion = await client.chat.completions.create({
        model: selectedModel,
        modalities: [
            "image",
            "text"
        ],
        messages: [
            {
                role: "user",
                content
            }
        ]
    });
    const message = completion.choices?.[0]?.message;
    const images = (message?.images || []).map((img)=>img.image_url?.url).filter((url)=>typeof url === "string" && url.length > 0);
    if (images.length === 0) {
        return Response.json({
            error: "No images returned from model.",
            rawMessage: completion.choices?.[0]?.message ?? null
        }, {
            status: 502
        });
    }
    return Response.json({
        images
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__ebfb06fd._.js.map