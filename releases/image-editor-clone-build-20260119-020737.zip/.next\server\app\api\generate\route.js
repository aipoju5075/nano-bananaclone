var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/[root-of-the-server]__5e1fe3b2._.js")
R.c("server/chunks/[root-of-the-server]__673530ed._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_5bfe9259.js")
R.m(77074)
module.exports=R.m(77074).exports
