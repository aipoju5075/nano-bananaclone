(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1252df3d._.js",
  "static/chunks/node_modules__pnpm_671da1da._.js"
],
    source: "dynamic"
});
