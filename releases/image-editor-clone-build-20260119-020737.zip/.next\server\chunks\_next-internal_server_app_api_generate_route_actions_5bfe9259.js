module.exports=[86500,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_generate_route_actions_5bfe9259.js.map