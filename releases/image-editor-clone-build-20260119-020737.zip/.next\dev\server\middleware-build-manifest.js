globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/1dff6_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f1d3f032._.js",
    "static/chunks/1dff6_next_dist_compiled_react-dom_987ad27f._.js",
    "static/chunks/1dff6_next_dist_compiled_react-server-dom-turbopack_b69c1d6b._.js",
    "static/chunks/1dff6_next_dist_compiled_next-devtools_index_b10aad90.js",
    "static/chunks/1dff6_next_dist_compiled_c5f28bd9._.js",
    "static/chunks/1dff6_next_dist_client_e3c2bcb2._.js",
    "static/chunks/1dff6_next_dist_4512f89c._.js",
    "static/chunks/69652_@swc_helpers_cjs_679851cc._.js",
    "static/chunks/_a0ff3932._.js",
    "static/chunks/turbopack-_8177140e._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];